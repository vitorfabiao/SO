#ifndef GESTOR_H_
#define GESTOR_H_
#include "estrutura.h"

void help();
void shutdown();



#endif